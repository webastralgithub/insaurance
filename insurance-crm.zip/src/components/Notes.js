

const  AdditionalInfo=(props)=>{

    const { id } = props;
    const parentNameNew = localStorage.getItem("parent");



return(

    <div className="add_property_btn">
      <div className="add_user_btn family_meber" >
        
      <h4>
          
      Additional Info
     
          </h4>
        
          </div>
      <div className="inner-pages-top">
      

          
{/*               
                    <input
                      name="Birthday"
                      value={birthday}
                      onChange={(e) => handleInputChange(e, index, 'firstname')}
                    />
                 
                 
                    <input
                     type="date"
                      name="email"
                      value={contact.email}
                      onChange={(e) => handleInputChange(e, index, 'email')}
                    /> */}
               

  
  
    </div>
    </div>
 
  
)


}
export default  AdditionalInfo